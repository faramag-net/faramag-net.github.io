const productos = [

  // LECHOSOS
  {
    nombre: "Beso de Ángel",
    precio: 22,
    tipo: "leche",
    activo: true,
    descripcion: "Cereza con trozos de Nuez, arandanos y coco",
    imagen: "../../../../imagenes/bolibeso.png",
    mensaje: "Quiero boli de Beso de Angel"
  },

  {
    nombre: "Coco",
    precio: 20,
    tipo: "leche",
    activo: true,
    descripcion: "",
    imagen: "../../../../imagenes/bolicoco.png",
    mensaje: "Quiero boli de Coco"
  },

  {
    nombre: "Fresa",
    precio: 20,
    tipo: "leche",
    activo: true,
    descripcion: "Con trozos de fresa",
    imagen: "../../../../imagenes/bolifresa.png",
    mensaje: "Quiero boli de Fresa"
  },

  {
    nombre: "Frutos Rojos",
    precio: 22,
    tipo: "leche",
    activo: true,
    descripcion: "",
    imagen: "../../../../imagenes/bolifrutos.png",
    mensaje: "Quiero boli Frutos Rojos"
  },

  {
    nombre: "Mamey",
    precio: 20,
    tipo: "leche",
    activo: true,
    descripcion: "",
    imagen: "../../../../imagenes/bolimamey.png",
    mensaje: "Quiero boli de Mamey"
  },

  {
    nombre: "Choco Nutella",
    precio: 24,
    tipo: "leche",
    activo: true,
    descripcion: "Chocolate y avellana en cada mordida",
    imagen: "../../../../imagenes/bolinuetlla.png",
    mensaje: "Quiero boli Choco Nutella"
  },

  {
    nombre: "Chocolate",
    precio: 20,
    tipo: "leche",
    activo: true,
    descripcion: "",
    imagen: "../../../../imagenes/bolichocolate.png",
    mensaje: "Quiero boli Chocolate"
  },

  {
    nombre: "Oreo",
    precio: 22,
    tipo: "leche",
    activo: true,
    descripcion: "",
    imagen: "../../../../imagenes/bolioreo.png",
    mensaje: "Quiero boli Oreo"
  },

  // HIELO

    {
    nombre: "Pepino con limón",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Refrescante limón con pepino",
    imagen: "../../../../imagenes/bolilimonpepino.png",
    mensaje: "Quiero boli Pepino con limón"
  },
  
  {
    nombre: "Mango chile y chamoy",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Picosita con pulpa y trozos de mango",
    imagen: "../../../../imagenes/bolimangochamoy.png",
    mensaje: "Quiero boli de Mango con chile y chamoy"
  },

  {
    nombre: "Tropical",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Refrescante mezcla de frutas tropicales",
    imagen: "../../../../imagenes/bolitropical.png",
    mensaje: "Quiero boli Tropical"
  },

  {
    nombre: "Mango",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Con pulpa y trozos de mango",
    imagen: "../../../../imagenes/bolimango.png",
    mensaje: "Quiero boli de Mango"
  },

  {
    nombre: "Piña",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Con pulpa de piña",
    imagen: "../../../../imagenes/bolipina.png",
    mensaje: "Quiero boli de Piña"
  },

  {
    nombre: "Piña con chile y chamoy",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Picosita y refrescante",
    imagen: "../../../../imagenes/bolipinachamoy.png",
    mensaje: "Quiero boli de Piña con chile y chamoy"
  },
  
  {
    nombre: "Oasis",
    precio: 18,
    tipo: "hielo",
    activo: true,
    descripcion: "Refrescante mezcla de fresa, naranja y papaya",
    imagen: "../../../../imagenes/bolioasis.png",
    mensaje: "Quiero boli Oasis"
  }

];

const contenido = document.getElementById("contenido");

function crearSeccion(titulo, lista) {

  const h2 = document.createElement("h2");
  h2.textContent = titulo;

  h2.className = "categoria-titulo";

  h2.textContent = titulo;

  const grid = document.createElement("div");
  grid.className = "grid";

  lista.forEach(producto => {

    const card = document.createElement("div");

    card.classList.add("producto");

    card.innerHTML = `
      <img src="${producto.imagen}" alt="${producto.nombre}">

      <p>${producto.nombre} - $${producto.precio}</p>

      <p class="descripcion">
        ${producto.descripcion}
      </p>
      
      <a class="btn"
         href="https://wa.me/5212225655003?text=${encodeURIComponent(producto.mensaje)}"
         target="_blank">
         Pedir por WhatsApp
      </a>
    `;

    grid.appendChild(card);

  });

  contenido.appendChild(h2);
  contenido.appendChild(grid);
}

crearSeccion(
  "🧊 Bolis de Agua Refrescantes",
  productos.filter(p => p.tipo === "hielo" && p.activo)
);

crearSeccion(
  "🥛 Bolis de Leche Cremosos",
  productos.filter(p => p.tipo === "leche" && p.activo)
);

const modal =
    document.getElementById("modalImagen");

const imagenGrande =
    document.getElementById("imagenGrande");

const cerrarModal =
    document.getElementById("cerrarModal");

document.addEventListener("click", e => {

    if(e.target.matches(".producto img")){

        imagenGrande.src =
            e.target.src;

        modal.style.display =
            "flex";
    }

});

cerrarModal.addEventListener("click", () => {

    modal.style.display =
        "none";

});

modal.addEventListener("click", e => {

    if(e.target === modal){

        modal.style.display =
            "none";
    }

});
